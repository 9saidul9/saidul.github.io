// ===== Animation চালু করার সংকেত =====
document.documentElement.classList.add("js");

// ===== টাইপিং ইফেক্ট (একাধিক লাইন ঘুরে ঘুরে) =====
const words = [
  "Portfolio",
  "Microsoft PowerPoint | Microsoft Word | Microsoft Excel",
  "Web Learner ..."
];
let w = 0, c = 0, deleting = false;
const typingEl = document.getElementById("typing");

function type() {
  const current = words[w];
  typingEl.textContent = current.substring(0, c);

  if (!deleting && c < current.length) {
    c++;
    setTimeout(type, 90);
  } else if (!deleting && c === current.length) {
    deleting = true;
    setTimeout(type, 1300);
  } else if (deleting && c > 0) {
    c--;
    setTimeout(type, 45);
  } else {
    deleting = false;
    w = (w + 1) % words.length;
    setTimeout(type, 300);
  }
}
type();

// ===== সাল নিজে থেকে বসবে =====
document.getElementById("year").textContent = new Date().getFullYear();

// ===== স্ক্রল করলে সেকশন ধীরে ভেসে উঠবে =====
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) entry.target.classList.add("show");
  });
}, { threshold: 0.15 });

document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));